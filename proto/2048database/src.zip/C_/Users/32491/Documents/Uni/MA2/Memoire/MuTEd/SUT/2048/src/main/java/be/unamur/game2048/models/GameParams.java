package be.unamur.game2048.models;

public class GameParams {
    public static final int sideLength = 4;
    public static final int nbStartTileFilled = 2;
    public static final int scoreTarget = 2048;
}
