package be.unamur.game2048.models;

public enum GameState {
    start, won, running, over
}
